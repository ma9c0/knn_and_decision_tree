# knn_and_decision_tree
problem 1 corresponds to problem1.ipynb and problem 2 corresponds to problem2.ipynb
directly running the whole file should lead to some results. 
By un-commenting the two blocks in cell 7, the cell for the main functions, will enable 
showing results for normalized dataset, as well as the performance on training dataset. 
The same for problem2.ipynb. By un-commenting blocks with title GINI and commenting 
code that are similar to what is being un-commenting (info gain) will provide results
for GINI criteria, and by un-commenting blocks in the stopping criteria will provide results
with stopping criteria described in the extra credit Qe.2.